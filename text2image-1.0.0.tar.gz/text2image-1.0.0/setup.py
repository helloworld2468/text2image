from setuptools import setup

setup(
    name='text2image',
    version='1.0.0',
    py_modules=['text2image'],
    install_requires=[
        'requests',
    ],
)